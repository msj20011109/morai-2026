; Auto-generated. Do not edit!


(cl:in-package simul_msgs-msg)


;//! \htmlinclude BBox2DArray.msg.html

(cl:defclass <BBox2DArray> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (boxes
    :reader boxes
    :initarg :boxes
    :type (cl:vector simul_msgs-msg:BBox2D)
   :initform (cl:make-array 0 :element-type 'simul_msgs-msg:BBox2D :initial-element (cl:make-instance 'simul_msgs-msg:BBox2D))))
)

(cl:defclass BBox2DArray (<BBox2DArray>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <BBox2DArray>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'BBox2DArray)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name simul_msgs-msg:<BBox2DArray> is deprecated: use simul_msgs-msg:BBox2DArray instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <BBox2DArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader simul_msgs-msg:header-val is deprecated.  Use simul_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'boxes-val :lambda-list '(m))
(cl:defmethod boxes-val ((m <BBox2DArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader simul_msgs-msg:boxes-val is deprecated.  Use simul_msgs-msg:boxes instead.")
  (boxes m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <BBox2DArray>) ostream)
  "Serializes a message object of type '<BBox2DArray>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'boxes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'boxes))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <BBox2DArray>) istream)
  "Deserializes a message object of type '<BBox2DArray>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'boxes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'boxes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'simul_msgs-msg:BBox2D))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<BBox2DArray>)))
  "Returns string type for a message object of type '<BBox2DArray>"
  "simul_msgs/BBox2DArray")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'BBox2DArray)))
  "Returns string type for a message object of type 'BBox2DArray"
  "simul_msgs/BBox2DArray")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<BBox2DArray>)))
  "Returns md5sum for a message object of type '<BBox2DArray>"
  "65af48fb3e12020635003909287f68ce")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'BBox2DArray)))
  "Returns md5sum for a message object of type 'BBox2DArray"
  "65af48fb3e12020635003909287f68ce")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<BBox2DArray>)))
  "Returns full string definition for message of type '<BBox2DArray>"
  (cl:format cl:nil "std_msgs/Header header~%BBox2D[] boxes~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: simul_msgs/BBox2D~%int32 xmin~%int32 ymin~%int32 xmax~%int32 ymax~%float32 confidence~%int32 class_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'BBox2DArray)))
  "Returns full string definition for message of type 'BBox2DArray"
  (cl:format cl:nil "std_msgs/Header header~%BBox2D[] boxes~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: simul_msgs/BBox2D~%int32 xmin~%int32 ymin~%int32 xmax~%int32 ymax~%float32 confidence~%int32 class_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <BBox2DArray>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'boxes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <BBox2DArray>))
  "Converts a ROS message object to a list"
  (cl:list 'BBox2DArray
    (cl:cons ':header (header msg))
    (cl:cons ':boxes (boxes msg))
))
