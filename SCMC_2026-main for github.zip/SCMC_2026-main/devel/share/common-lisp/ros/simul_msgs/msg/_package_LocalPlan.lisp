(cl:in-package simul_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          ACTIVE-VAL
          ACTIVE
          STOP-VAL
          STOP
          SPEED_LIMIT_KMH-VAL
          SPEED_LIMIT_KMH
          STATE-VAL
          STATE
          PATH-VAL
          PATH
))