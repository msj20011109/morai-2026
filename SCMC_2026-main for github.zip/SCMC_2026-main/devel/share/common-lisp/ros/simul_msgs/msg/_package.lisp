(cl:defpackage simul_msgs-msg
  (:use )
  (:export
   "<BBOX2D>"
   "BBOX2D"
   "<BBOX2DARRAY>"
   "BBOX2DARRAY"
   "<CONTROLCMD>"
   "CONTROLCMD"
   "<LOCALPLAN>"
   "LOCALPLAN"
   "<TRAFFICSIGN>"
   "TRAFFICSIGN"
   "<VEHICLESTATUS>"
   "VEHICLESTATUS"
  ))

