(cl:in-package simul_msgs-msg)
(cl:export '(XMIN-VAL
          XMIN
          YMIN-VAL
          YMIN
          XMAX-VAL
          XMAX
          YMAX-VAL
          YMAX
          CONFIDENCE-VAL
          CONFIDENCE
          CLASS_ID-VAL
          CLASS_ID
))