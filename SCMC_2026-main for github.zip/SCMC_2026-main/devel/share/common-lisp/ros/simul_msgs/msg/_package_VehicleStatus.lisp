(cl:in-package simul_msgs-msg)
(cl:export '(VEL_X-VAL
          VEL_X
          YAW-VAL
          YAW
))