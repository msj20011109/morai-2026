
(cl:in-package :asdf)

(defsystem "simul_msgs-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :nav_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "BBox2D" :depends-on ("_package_BBox2D"))
    (:file "_package_BBox2D" :depends-on ("_package"))
    (:file "BBox2DArray" :depends-on ("_package_BBox2DArray"))
    (:file "_package_BBox2DArray" :depends-on ("_package"))
    (:file "ControlCmd" :depends-on ("_package_ControlCmd"))
    (:file "_package_ControlCmd" :depends-on ("_package"))
    (:file "LocalPlan" :depends-on ("_package_LocalPlan"))
    (:file "_package_LocalPlan" :depends-on ("_package"))
    (:file "TrafficSign" :depends-on ("_package_TrafficSign"))
    (:file "_package_TrafficSign" :depends-on ("_package"))
    (:file "VehicleStatus" :depends-on ("_package_VehicleStatus"))
    (:file "_package_VehicleStatus" :depends-on ("_package"))
  ))