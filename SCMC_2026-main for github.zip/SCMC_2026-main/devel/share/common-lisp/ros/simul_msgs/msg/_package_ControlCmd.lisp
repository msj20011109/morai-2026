(cl:in-package simul_msgs-msg)
(cl:export '(ACCEL-VAL
          ACCEL
          BRAKE-VAL
          BRAKE
          STEERING-VAL
          STEERING
))