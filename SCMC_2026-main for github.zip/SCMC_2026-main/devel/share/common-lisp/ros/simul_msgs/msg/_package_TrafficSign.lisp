(cl:in-package simul_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          TRAFFIC_SIGN-VAL
          TRAFFIC_SIGN
))