(cl:defpackage lidar_object_detection-msg
  (:use )
  (:export
   "<BOUNDINGBOX>"
   "BOUNDINGBOX"
   "<NEARESTOBSTACLEINFO>"
   "NEARESTOBSTACLEINFO"
   "<OBJECTINFO>"
   "OBJECTINFO"
   "<POINTINFO>"
   "POINTINFO"
  ))

