(cl:in-package lidar_object_detection-msg)
(cl:export '(X-VAL
          X
          Y-VAL
          Y
))