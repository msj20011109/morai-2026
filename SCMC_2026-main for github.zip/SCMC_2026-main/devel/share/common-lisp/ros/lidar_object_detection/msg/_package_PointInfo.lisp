(cl:in-package lidar_object_detection-msg)
(cl:export '(BBOXCOUNTS-VAL
          BBOXCOUNTS
          XMINI-VAL
          XMINI
          YMINI-VAL
          YMINI
          ZMINI-VAL
          ZMINI
          XMAXI-VAL
          XMAXI
          YMAXI-VAL
          YMAXI
          ZMAXI-VAL
          ZMAXI
))