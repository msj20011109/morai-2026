(cl:in-package lidar_object_detection-msg)
(cl:export '(HEADER-VAL
          HEADER
          OBJECTCOUNTS-VAL
          OBJECTCOUNTS
          CENTERX-VAL
          CENTERX
          CENTERY-VAL
          CENTERY
          CENTERZ-VAL
          CENTERZ
          LENGTHX-VAL
          LENGTHX
          LENGTHY-VAL
          LENGTHY
          LENGTHZ-VAL
          LENGTHZ
))