
(cl:in-package :asdf)

(defsystem "lidar_object_detection-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "BoundingBox" :depends-on ("_package_BoundingBox"))
    (:file "_package_BoundingBox" :depends-on ("_package"))
    (:file "NearestObstacleInfo" :depends-on ("_package_NearestObstacleInfo"))
    (:file "_package_NearestObstacleInfo" :depends-on ("_package"))
    (:file "ObjectInfo" :depends-on ("_package_ObjectInfo"))
    (:file "_package_ObjectInfo" :depends-on ("_package"))
    (:file "PointInfo" :depends-on ("_package_PointInfo"))
    (:file "_package_PointInfo" :depends-on ("_package"))
  ))