# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(morai_msgs_MSG_INCLUDE_DIRS "/home/moon/다운로드/SCMC_2026-main/src/MORAI-ROS_morai_msgs/msg")
set(morai_msgs_MSG_DEPENDENCIES geometry_msgs;std_msgs)
